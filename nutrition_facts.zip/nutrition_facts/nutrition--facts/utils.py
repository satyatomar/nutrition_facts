#nutrition_facts

def get_nutrition(item=None):

        if item is None:
                print("Enter a valid entry")

        elif item == "mango":
                print("123321")

        else:
                print("Thanks")





