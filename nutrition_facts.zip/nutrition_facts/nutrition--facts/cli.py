
from utils import *


def main():
        get_nutrition()

        


if __name__ == "__main__":
	main()
